package com.tuhinadas.minweather;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.renderscript.ScriptGroup;
import android.util.JsonReader;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toolbar;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONTokener;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Scanner;


public class MainActivity extends AppCompatActivity {

    /*
     * Some other misc API stuff to keep a track of, so I don't
     * forget.
     *
     * API: weatherstack
     * API key: 03f121805882bc06c0850ab48ff892b9
     * Usage: 1000 requests per month
     *
     *
     * Test zip codes:
     * Ptx: 75025
     * Springfield: 45505
     * Boynton Beach: 33424
     * Seattle: 98101
     * New York: 10001
     */

    /*
     * Creating the thread that will request API for info
     * and the Handler that processes messages
     */
    Handler mHandlerThread = new Handler();
    WeatherThread wt;

    /*
     * Two final ints that will track whether or not there is an
     * error based on the Message the handler receives.
     * (Remember, anything 400+ is bad)
     */
    static final int MSG_OK = 1;
    static final int MSG_ERR = 2;

    /*
     * Hooking all UI components up to variables
     * so the program can respond to their use
     */
    ImageButton btnSearch;
    TextView rvWeather;
    TextInputEditText input;
    ImageView weathercon;
    TextView mainInfo;
    TextView weatherDesc;

    /* I don't think I will use this as it's just
     * meant to show the title of the app,
     * but I'm creating a variable just in case.
     */
    Toolbar titleBar;


    /*
    boolean to keep a track of whether it's °F or °C
     */

    boolean isC = true;
    Button btnTemp;
    int t;
    int f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //TODO: initialize all UI variables here
        btnTemp=findViewById(R.id.TEMP_BUTTON);
        mainInfo = findViewById(R.id.INFO);
        weatherDesc = findViewById(R.id.INFO2);
        weathercon = findViewById(R.id.WEATHER_ICON);
        rvWeather = findViewById(R.id.RV_LIST);
        btnSearch = findViewById(R.id.BTN_SEARCH);
        input = findViewById(R.id.ZIP_INPUT);

        btnTemp.setOnClickListener(new ButtonClick2());
        btnSearch.setOnClickListener(new ButtonClick());


        //TODO: create recyclerview to list out the data underneath search bar?
    }

    @Override
    public void onResume() {
        super.onResume();
        mHandlerThread = new HandleMsg(this);
    }

    /*
     * Creating a thread inner class for the thread that will send an API request
     * over
     */
    public class WeatherThread extends Thread{
        /*TODO: why do we need this? find the answer as you go along*/
        public String weatherURL;
        public String zip;


        /*Variable to verify that this thread is running.
         * If this variable is true, disable the button to
         * prevent spam requests.
         */
        boolean isRunning=true;

        /*create a constructor that initializes the URL upon construction
         of the thread*/
        public WeatherThread(String url){
//            zip = z;
            weatherURL=url;
        }

        /*The "main" method that occurs when thread starts*/
        @Override
        public void run()
        {
            URL url = null;
            /*String to hold a line of info from the JSON
             * InputStream to well... get input.
             * Scanner to scan that input.
             * Response to save the HTTP response code.*/
            String strLine="";
            InputStream stream = null;
            Scanner scanner = null;
            int response = 0;

            /*TODO: better understand what a bundle is for. I can't seem to get it.*/
            Bundle bError = new Bundle();
            Message errMsg = new Message();

            try{
                url = new URL(weatherURL);
                URLConnection connection = url.openConnection();
                /*TODO: better understand difference between urlconn and httpcon*/
                HttpURLConnection httpConn = (HttpURLConnection) connection;
                response = httpConn.getResponseCode();

                //If the response code is good, then start parsing the JSON provided by API
                if (response == HttpURLConnection.HTTP_OK){
                    stream = httpConn.getInputStream();
                    /*What the HTTP connection is returning is basically text.
                     * So create a String to store ALL of the text in.
                     * Then, create a JSON object from the String.
                     */

                    /*TODO: why do we need a JSON obj to begin with?
                     * can we just bypass that and use text?
                     */
                    stream = httpConn.getInputStream();

                    //Create a new json obj equal to the file we get from connection
                    scanner = new Scanner(stream);
                    while (scanner.hasNext()){
                        strLine = scanner.nextLine();
                    }
                    scanner.close();
                    /*TODO: why do we disconnect?*/
                    httpConn.disconnect();

                    //create new json obj from json string
                    JSONObject jo = new JSONObject(strLine);
                    String city =  jo.getJSONObject("location").getString("name");
                    String state = jo.getJSONObject("location").getString("region");
                    city += ", " + state;

                    String description =  jo.getJSONObject("current").getJSONArray("weather_descriptions").getString(0);

                    int temp = jo.getJSONObject("current").getInt("temperature");
                    int feel = jo.getJSONObject("current").getInt("feelslike");
                    String currentTemp ="";
                    String feels = "";
                    if (isC){
                        currentTemp= temp + " °C";
                        feels= "Feels like " + feel + " °C";
                    }
                    else{
                        temp = (int) ((9/5.0) *temp + 32);
                        feel = (9*feel)/5 + 32;
                        currentTemp= temp + " °F";
                        feels= "Feels like " + feel + " °F";
                    }

                    String wind = "There is a wind blowing " + jo.getJSONObject("current").getString("wind_dir");

                    int uv = jo.getJSONObject("current").getInt("uv_index");
                    String danger = "UV: ";
                    if (uv <= 2){
                        danger += "Low. You can safely be outside :)";
                    }
                    else if (uv >= 3 && uv <= 5){
                        danger += "Moderate. Seek shade during midday hours! Sunscreen and a hat are recommended";
                    }
                    else{
                        danger += "Extremely high. Avoid being outside during midday hours. Seek shade. Shirt, sunscreen and a hat are a must!";
                    }

                    String info = "";
                    String main = "";
//                    main += city + "\n" + description;
                    info +=  "\n" + feels +  "\n\n" + wind + "\n\n" + danger;

                    String[] values = {info, city, description,(description+" "+currentTemp)};
                    //Create a new bundle to send the ArrayList back
                    Bundle b = new Bundle();
//                    b.putStringArrayList("list", returnList);

                    b.putStringArray("list", values);
                    Message message = new Message();
                    message.what = MSG_OK;
                    /*TODO: why do we do this?????*/
                    message.setData(b);
                    mHandlerThread.sendMessage(message);
                }
                else{
                    //If the response code is bad, then create an error message
                    errMsg = new Message();
                    errMsg.what = MSG_ERR;
                    bError.putString("E", "Bad response: " + response);
                    errMsg.setData(bError);
                    mHandlerThread=new Handler();
                    mHandlerThread.sendMessage(errMsg);
                }

            }
            catch(Exception e)
            {
                bError.putString("E", e.getMessage());
                errMsg.setData(bError);
                mHandlerThread.sendMessage(errMsg);
            }
        }
    }

    /*Create a button clicker class that defines what the button does
     * when clicked */
    private class ButtonClick implements View.OnClickListener
    {
        @Override
        public void onClick(View v) {
            String strURL = "http://api.weatherstack.com/current?access_key=03f121805882bc06c0850ab48ff892b9&query=";
            String zipSymbol = input.getText().toString();

            //hide the keyboard when the search button is pressed
            View view = findViewById(R.id.RV_LIST);
            if (view != null) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
            }

            //TODO: Would I add a .json at the end, since I'm requesting a JSON obj?
            //Answer: Yes
            wt = new WeatherThread(strURL + zipSymbol +".json");
            wt.start();
        }
    }

    /*
     * Create a button clicker class to change the boolean isC
     */

    private class ButtonClick2 implements View.OnClickListener
    {
        @Override
        public void onClick(View v) {
            isC=(!isC);
        }
    }



    private class HandleMsg extends Handler {
        //get the current activity
        MainActivity parent;

        //custom adapter to put together new info
        CustomAdapter adapter;

        public HandleMsg(MainActivity p){parent = p;}

        public void handleMessage(Message msg){
            super.handleMessage(msg);
            switch (msg.what)
            {
                //if message is OK
                case MSG_OK:
                    //get the bundled data from msg returned
                    Bundle b = msg.getData();
                    //get the string arraylist containing data
                    String[] weatherData = b.getStringArray("list");
                    try {
                        //create a new adapter and feed the new arraylist in
//                        adapter = new CustomAdapter(weatherData);
//                        rvWeather.setLayoutManager(new LinearLayoutManager(parent));
                        // set the recyclerView's adapter to this new adapter with new data
                        mainInfo.setText(weatherData[1]);
                        weatherDesc.setText(weatherData[3]);
                        rvWeather.setText(weatherData[0]);
                        if (weatherData[2].contains("Sunny") || weatherData[2].contains("Clear")){
                            weathercon.setImageResource(R.drawable.cutesun1);
                        }
                        else if (weatherData[2].contains("Overcast")){
                            weathercon.setImageResource(R.drawable.cloud);
                        }
                        else if (weatherData[2].contains("Partly cloudy")){
                            weathercon.setImageResource(R.drawable.partlycloud);
                        }
                        else if (weatherData[2].contains("Thunderstorm")){
                            weathercon.setImageResource(R.drawable.thunderstorm);
                        }
                        else if (weatherData[2].contains("Light rain")){
                            weathercon.setImageResource(R.drawable.rain);
                        }


                    }
                    //catch if something goes wrong
                    catch(Exception ex)
                    {
                        //I do not have a TextView for message errors, so this has been left blank.
                        // I'll probably put a print statement here to see if it actually executes.

                    }
                    break;

                //if msg is BAD then just break, there's nothing else to do
                case MSG_ERR:
                    break;
            }
        }
    }

}