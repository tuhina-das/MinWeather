package com.tuhinadas.minweather;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

//a customAdapter object has a local data set it reads from to update data
public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.ListRow> {

    private ArrayList<String> localDataSet;

    //initializes new data set
    public CustomAdapter(ArrayList<String> list)
    {
        localDataSet = list;
    }

    @NonNull
    @Override
    //creates a viewholder for when the recyclerview has no viewholders to recycle from.
    // returns a listrow object.
    public ListRow onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.rowlayout, parent, false);
        return new ListRow(view) {

        };
    }


    @Override
    public void onBindViewHolder(@NonNull ListRow holder, int position) {
        String[] text = localDataSet.get(position).split(",");
        holder.tvCity.setText(text[0]);
        holder.tvTemp.setText(text[1]);
    }

    @Override
    public int getItemCount() {
        return localDataSet.size();
    }


    // inner class for the listRow object, which displays a list row
    public class ListRow extends RecyclerView.ViewHolder
        //TODO: rewrite this class to fit our data
    {
        public TextView tvCity;
        public TextView tvTemp;
        public ListRow(@NonNull View itemView) {
            super(itemView);
            tvCity=itemView.findViewById(R.id.ID_CITY);
            tvTemp=itemView.findViewById(R.id.ID_TEMP);
        }
    }
}
